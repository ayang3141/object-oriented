
public interface IEvent {
	
	public double pointsEarned();
	
	public double getPenalties();
	
	
		
}
