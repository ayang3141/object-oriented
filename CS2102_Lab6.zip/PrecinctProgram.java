import java.util.Scanner;

public class PrecinctProgram {
	
	
	
	public static void main(String[] args) {
		Precinct worcester12;
		worcester12 = new Precinct("Worcester12", "130 Winter Street", 1673);
		
		Scanner keyboard = new Scanner(System.in);
		
//		System.out.println("Please enter in number of new people: ");
//		int amount = keyboard.nextInt();
//		Precinct newWorcester12 = worcester12.grow(amount);
		
		System.out.println("Please enter the population, name, and address of the new precinct: ");
		int pre_pop = keyboard.nextInt();
		
		// Finishes reading the whitespace after input integer
		keyboard.nextLine();	
		
		String pre_name = keyboard.nextLine();
		String pre_address = keyboard.nextLine();
		
		
		Precinct newWorcester12 = new Precinct(pre_name, pre_address, pre_pop);

		System.out.println(newWorcester12);
		
		
		
		
		
		
	}

}
